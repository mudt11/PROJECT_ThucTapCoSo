import { useEffect, useRef } from "react";
import axios from "axios";

type Params = {
  track: {
    trackId: number;
    duration: number;
  } | null;
  audioState: {
    currentTime: number;
    duration: number;
  };
  isPlaying: boolean;
  source?: "search" | "playlist" | "recommendation" | "radio";
};

type EventType = "start" | "pause" | "resume" | "progress" | "seek" | "end";

export function useActivityLogger({
  track,
  audioState,
  isPlaying,
  source = "playlist",
}: Params) {
  const sessionIdRef = useRef<string | null>(null);
  const lastTimeRef = useRef<number>(0);
  const prevTrackRef = useRef<number | null>(null);
  const hasStartedRef = useRef(false);
  const wasPlayingRef = useRef(false);
  const lastSentRef = useRef(0);
  const hasEndedRef = useRef(false);

  useEffect(() => {
    console.log("DEBUG LOGGER:", { track, isPlaying });
  }, [track, isPlaying]);

  const sendLog = async (eventType: EventType, delta = 0) => {
    console.log("SEND EVENT:", eventType, {
      track,
      currentTime: audioState.currentTime,
    });
    if (!track) return;
    if (!sessionIdRef.current) return;

    // throttle
    if (Date.now() - lastSentRef.current < 1000) return;
    lastSentRef.current = Date.now();

    try {
      await axios.post(
        "http://localhost:5000/api/activity",
        {
          song_id: track?.trackId,
          session_id: sessionIdRef.current,
          event_type: eventType,
          listened_delta: delta,
          position: audioState.currentTime,
          song_duration: track.duration || audioState.duration,
          source,
        },
        {
          withCredentials: true,
        },
      );
    } catch (err) {
      console.error("Activity log error:", err);
    }
  };

  // play / pause / resume
  useEffect(() => {
    console.log("isPlaying:", isPlaying);
    if (!track) return;

    if (isPlaying && !hasStartedRef.current) {
      sessionIdRef.current = crypto.randomUUID();

      sendLog("start");
      hasStartedRef.current = true;
      hasEndedRef.current = false;
    } else if (isPlaying && !wasPlayingRef.current) {
      sendLog("resume");
    } else if (!isPlaying && wasPlayingRef.current) {
      sendLog("pause");
    }

    wasPlayingRef.current = isPlaying;
  }, [isPlaying, track]);

  // progress
  useEffect(() => {
    if (!isPlaying || !track) return;

    const interval = setInterval(() => {
      const current = audioState.currentTime;
      const delta = current - lastTimeRef.current;

      if (delta > 0 && delta < 3) {
        sendLog("progress", delta);
      }

      lastTimeRef.current = current;
    }, 5000);

    return () => clearInterval(interval);
  }, [isPlaying, track]);

  // track change
  useEffect(() => {
    if (!track) return;

    if (prevTrackRef.current && prevTrackRef.current !== track.trackId) {
      sendLog("end"); // kết thúc bài cũ

      sessionIdRef.current = null;
      hasStartedRef.current = false;
      hasEndedRef.current = false;
      lastTimeRef.current = 0;
    }

    prevTrackRef.current = track.trackId;
  }, [track?.trackId]);

  // reset time
  useEffect(() => {
    lastTimeRef.current = audioState.currentTime;
  }, [track?.trackId]);

  // seek
  const sendSeekLog = (newTime: number) => {
    sendLog("seek", Math.abs(newTime - lastTimeRef.current));
    lastTimeRef.current = newTime;
  };

  // unmount
  useEffect(() => {
    return () => {
      if (track) {
        navigator.sendBeacon(
          "http://localhost:5000/api/activity",
          JSON.stringify({
            song_id: track.trackId,
            session_id: sessionIdRef.current,
            event_type: "end",
            position: audioState.currentTime,
            song_duration: audioState.duration,
            listened_delta: 0,
            source,
          }),
        );
      }
    };
  }, []);

  return { sendSeekLog };
}
